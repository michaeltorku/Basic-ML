import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class HeapsortTester {

	@Test
	public void testHeapsort1() {
		int c[]= { 5 };
		Heapsort.heapsort(c);
		assertEquals(5, c[0]);

		c= new int[] { 5, 4, 3, 2, 1, 0 };
		Heapsort.heapsort(c);
		for (int k= 0; k < c.length; k= k + 1) {
			assertEquals(k, c[k]);
		}
	}

	@Test
	public void testHeapsort() {
		int c[]= { 5, 2, 4, 6, 1, -5, 8, 5, 4, 3, 9, 10, 11, 12 };
		Heapsort.heapsort(c);
		assertEquals(-5, c[0]);
		assertEquals(1, c[1]);
		assertEquals(2, c[2]);
		assertEquals(3, c[3]);
		assertEquals(4, c[4]);
		assertEquals(4, c[5]);
		assertEquals(5, c[6]);
		assertEquals(5, c[7]);
		assertEquals(6, c[8]);
		assertEquals(8, c[9]);
		assertEquals(9, c[10]);
		assertEquals(10, c[11]);
		assertEquals(11, c[12]);
		assertEquals(12, c[13]);
	}

}
