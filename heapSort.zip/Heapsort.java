/** Contains static method sort to sort an int array using heapsort. */
public class Heapsort {
	/** README: Procedure heapsort comes first. It has two parts,<br>
	 * (1) Make its parameter b into a max-heap. <br>
	 * (2) Extract elements from the heap, one by one, from largest to smallest, <br>
	 * and put them in the right place.
	 *
	 * In order to do this, a max-heap and not a min-heap is used. This means <br>
	 * that every value in the heap is >= its children. We write "max-heap"<br>
	 * instead of "heap" everywhere below as a reminder.
	 *
	 * Here is the max-heap invariant for array segment b[0..n-1].<br>
	 *
	 * /** Max-heap invariant for b[0..n-1], i.e.<br>
	 * 1. All elements of b[0..n-1] are filled with a value <br>
	 * 2. The children of each b[i] are b[2i+1] and b[2i+2]<br>
	 * 3. The parent of each b[i] is b[(i-1)/2]<br>
	 * 4. The children of a node b[i] are <= b[i] */

	/** Sort b. */
	public static void heapsort(int[] b) {
		// Make b into a max-heap
		// invariant: b[0..k-1] is a max-heap AND
		// b is a permutation of its initial value
		for (int k= 1; k < b.length; k= k + 1) {
			// Make b[0..k] into a max-heap by bubbling b[k] up
			bubbleUp(b, k);
		}

		// Sort the max-heap
		// invariant: b[0..k] is a max-heap AND
		// b[k+1..] is sorted AND
		// b[0..k] <= b[k+1..] AND
		// b is a permutation of its initial value
		for (int k= b.length - 1; k > 0; k= k - 1) {
			// Swap b[0] and b[k]
			int t= b[0];
			b[0]= b[k];
			b[k]= t;
			bubbleDown(b, k);
		}
	}

	/** Bubble b[k] up so that b[0..k] is a max-heap. <br>
	 * Precondition: b[0..k] is a max-heap except that b[k] may have a smaller parent. */
	public static void bubbleUp(int[] b, int k) {
		int p= (k - 1) / 2;   // p is the parent of k

		// inv: p is the parent of k AND
		// original b[0..k-1] is a max-heap except: b[k] might be larger than b[p].
		while (k > 0 && b[k] > b[p]) {
			// Swap b[k] and b[p]
			int t= b[k];
			b[k]= b[p];
			b[p]= t;

			k= p;
			p= (k - 1) / 2;
		}
	}

	/** Max-Heapify b[0..k-1] by bubbling b[0] down to its heap position. <br>
	 * Precondition: b[0..k-1] is a max-heap except that b[0] may have a larger child */
	public static void bubbleDown(int[] b, int k) {
		int h= 0;
		// in: b[0..k-1] is a max-heap except that
		// b[h] may be larger than one of its children.
		while (h < k) {
			// Set c to the larger child of h but return if h has no children
			int c= 2 * h + 1;                     // h's smallest child
			if (c > k - 1) return;
			if (c < k - 1 && b[c] < b[c + 1]) c= c + 1;

			if (b[h] >= b[c]) return;  // b[h] is in the right place

			// Swap b[n] and b[c]
			int t= b[h];
			b[h]= b[c];
			b[c]= t;

			h= c;
		}
	}
}